'''
@author: Christopher Sowers
Description: Randomly choses 2 dice, each with six sides, rolls them, and then
shows the values from both dice individually and then the value of them together

import random

######### VARIABLES #########
sides = 6

######### MAIN FUNCTION #########
firstDice = random.randint(1,sides)
#Choses a random first number ranging from 1-6
secondDice = random.randint(1,sides)
#Choses a random second number ranging from 1-6
print ("You rolled a",firstDice,"and a",secondDice)
#Prints the numbers randomly chosen
print ("Sum of the dice:",firstDice + secondDice)
#prints the sum of the two numbers
'''

'''
@author: Christopher Sowers
Description:

Create an application which will continuously ask for grades (0-100) for 
assignments.  Once the user inputs a 'q', the program should output the average 
of all of the input grades.
'''

grades = 0
q = False
englishGrade = " "
mathGrade = " "
physicalEducationGrade = " "
socialStudiesGrade = " "

while q == False:
    if englishGrade = int(input("Grade: "))
        