'''
@author: Christopher Sowers
Description: The computer chooses a random number between 1 and 100 and asks
you to guess the number. The user only has 10 tries and the computer will tell
you if the guess was too low or too high.
'''
########## VARIABLES ##########

tries = 0

########## FIRST WHILE LOOP AND COMPUTER CHOSEN NUMBER ##########

import random
randomNumber = random.randint(1, 100)
#Tells the computer to pick a random number between 1 and 100 and store it
while tries != 10:
    try:
        #Attempts to use the user inputed data but if the
        #user inputed data is not an integer or any number at all it will
        #refuse to take that as an input and it will ask the user to provide a 
        #valid number instead
        numberChosen = int(input("Guess a number between 1 and 100: "))
            #Takes the user input and converts it from a string to an integer
        if numberChosen == randomNumber:
            #Compares the user chosen number and the computer chosen number and
            #checks to see if they are the same; if they are then the program
            #tells you that you got it right and shows you the amount of tries
            #it took to get it
            print("You guessed it in:",tries,"out of 10 tries!")
            break
        elif numberChosen != randomNumber:
            #Compares the user chosen number and the computer chosen number and
            #checks to see if they are different; if they are then the program
            #continues to run until the user uses up all of their tries or
            #guesses the number right
        
########## SECOND WHILE LOOP ##########

            while numberChosen != randomNumber:
                #A loop that allows the user to input a number again until they
                #run out of tries or guess it right
                if numberChosen < randomNumber:
                    tries += 1
                    #Adds a value of 1 to the variable tries
                    print("Guess is too low, you are at ", tries, \
                       "out of 10 tries!")
                    break
                elif numberChosen > randomNumber:
                    tries += 1
                    #Adds a value of 1 to the variable tries
                    print("Guess is too high, you are at ", tries, \
                          "out of 10 tries!")
                    break
            
    except ValueError:
        print("That is not a valid number")
    #Tells the user that the inputed number was invalid and forces them to
    #try again

if tries == 10:
    print("You didn't guess it in 10 tries! The number was:", randomNumber)
else:
    print("I bet you won't guess it next time!")
            
        
        