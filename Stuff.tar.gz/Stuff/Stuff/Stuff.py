'''
def b(c):
    for x in range(c):
        print(c)

print(b(4))
print(b('h'))
'''
from builtins import int

'''
def d(list):
    list = ["1","2","3","4"]
    x = 0
    while x <= len(list):
        print(list[0])
'''

'''
Write a program which accepts the radius of a circle, and returns the area.
HINT: the area of a circle is pi*radius*radius
pi can be estimated at 3.141529
'''
radius = 0
pi = 3.141529

while radius <= 0:
    try:
        radiusChosen = int(input("Input the radius of the circle: "))
    
    if input = int:
        break
    
    except ValueError:
        print("That is not a valid number")