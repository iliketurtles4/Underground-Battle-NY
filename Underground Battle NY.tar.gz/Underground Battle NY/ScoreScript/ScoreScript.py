'''
@author: VolvagiaPrime
'''

newScore = 0
scoreThree = 0
scoreTwo = 0
scoreOne = 0

while newScore > scoreThree:
    
    if newScore < scoreTwo:
        scoreThree = newScore
        break
        
    if newScore < scoreOne:
        scoreThree = scoreTwo
        scoreTwo = newScore
        break
        
    if newScore > scoreOne:          
        scoreThree = scoreTwo
        scoreTwo = scoreOne
        scoreOne = newScore
        break

print("Score Three:",scoreThree)
print("Score Two:",scoreTwo)
print("Score One:",scoreOne)