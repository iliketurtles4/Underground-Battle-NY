'''
@author: VolvagiaPrime
Description: Battle for New York in the subway systems beneath the city as
 hideous creatures come out of the dark and try to kill you!
 Stemming from years of hazardous, toxic waste in the sewers, fight for
 you own survival along with humanity's as unrelenting waves of slime, thrall,
 and other abominations try to stop you from saving the world. As you fight
 through the underground, the streets, and eventually the sky, go up againt
 stronger and tougher enemies, mutated foes, and all sorts of other terrifying
 things from the deep.
'''
import pygame
import sys, os, math
from pygame import *
from random import randint
from spriteHelper import SpriteSheet
from orca.eventsynthesizer import clickCharacter
from pyatspi import state
from reportlab.pdfbase.pdfform import ButtonStream

WINDOWWIDTH = 1024
WINDOWHEIGHT = 768
GAMENAME = "Underground Battle NY"
FRAMERATE = 60
BGCOLOR = (255,255,255)
#RED = (255,0,0)
#GREEN = (0,255,0)
#BLUE = (0,0,255)
#BLACK = (0,0,0)
#WHITE = (255,255,255)
#These are for quick color access

'''
mainMenu = True
startButton = False
optionButton = False
quitButton = False

while mainMenu == True:
    x = WINDOWWIDTH
    y = WINDOWHEIGHT
    menuBG = pygame.image.load('mainMenuBG.png')
    
    
    #Init is used to initialize classes
    def __init__(self):
        pygame.init()
        self.clock = pygame.time.Clock()
        self.surface = pygame.display.set_mode((WINDOWWIDTH,WINDOWHEIGHT))
        pygame.display.set_caption(GAMENAME)
    
    
    def drawMenuBackGround(x,y):
        surface.blit(menuBG,(x*0.45,y*0.8))
        
    startButton = (button)

    optionButton = (button)
    
    quitButton = (button)
     
    
    
    if startButton == True:
        pass
    if optionButton == True:
        pass
    if quitButton == True:
        sys.exit()
'''

class Button:
    ########## VARIABLES ##########
    imageUp = None
    imageDown = None
    imageOver = None
    state = False
    mouseOver = None
    x = 0
    y = 0
    callback = None
    image = None
    
    ########## CONSTRUCTOR ##########
    def __init__(self,callback,imageUp,imageDown,imageOver):
        self.callback = callback
        #callback is used in non linear programming languages because there
        #is no guarantee that a line of code will be completely read and stored
        #before the computer reads the next line so this prevents inconsistency
        self.imageUp = imageUp
        self.imageDown = imageDown
        self.imageOver = imageOver
        self.image = imageUp
        # these variables are global variables because the global variables
        #callback, imageUp, imageDown, and imageOver are set to the local
        #versions in this function
        
    ########## MAIN FUNCTION ##########
    def click(self):
        ''' the function runs when the button is clicked'''
        self.callback()
        
    def draw(self,surface):
        surface.blit(self.image,(self.x,self.y))
        #draws the images for the buttons to the screen
        
    def mouseOver(self):
        self.image = self.imageOver
        #Function that detects when the mouse moves over the button
        self.state = False
        
    def mouseOut(self):
        self.image = self.imageUp
        #Function that detects when the mouse is no longer on the button
        self.state = False
        
    def mouseDown(self):
        self.image = self.imageDown
        #Function that detects when the mouse is held down
        self.state = True
        #Detects when the mouse button is pressed and allows it to do something
        
    def getCollider(self):
        collider = self.image.get_rect()
        collider.x = self.x
        collider.y = self.y
        return collider
        
    def update(self,delta):
        #Checks to see if mouse is over button
        collider = self.getCollider()
        mouseLoc = pygame.mouse.get_pos()
        mouseLoc = pygame.Rect(mouseLoc[0],mouseLoc[1],5,5)
        mouseState = pygame.mouse.get_pressed()
        #Puts a rectangle on the mouse to detect collisions
        if collider.colliderect(mouseLoc):
            #checks to see if the mouse collides with the image and if it does
            #then the button changes to the mouse over sprite
            if mouseState[0]:
                self.mouseDown()
            else:
                if self.state == True:
                    self.state = False
                    self.click()
                self.mouseOver()
        else:
            self.mouseOut()
        #Checks to see if mouse button is held down
        
    
class Player:
    #Description: Class used to identify the player
    ########## VARIABLES ##########
    x = (WINDOWWIDTH / 2)
    y = (WINDOWHEIGHT / 2)
    collider = None
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        self.image = SpriteSheet("mainMenuBG.png")
        self.image = self.image.get_image(0,0,1024,768)
    ########## MAIN FUNCTION ##########
    def draw(self,surface):
        #Draws the player sprite on the screen
        surface.blit(self.image,(self.x,self.y))
    
    def getCollider(self):
        #Returns a rectangle area representing the player sprite
        pass

    def getCenter(self):
        rect = self.image.get_rect()
        return (rect.w/2,rect.h/2)
        #Here X and Y cannot be used because it will cause the computer to use
        #the coordinates (0,0) on the rectangle

class Game:
    ########## VARIABLES ##########
    score = 0
    levels = []
    topScores = []
    player = None
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pygame.init()
        self.clock = pygame.time.Clock()
        self.surface = pygame.display.set_mode((WINDOWWIDTH,WINDOWHEIGHT))
        pygame.display.set_caption(GAMENAME)
        self.player = Player()
    ########## MAIN FUNCTION ##########
    def main(self):
        playing = True
        
        ########## START BUTTON CODE ##########
        
        startButtonSprites = SpriteSheet("button-start-spritesheet.png")
        startButtonUp = startButtonSprites.get_image(0,0,201,72)
        #Grabs the middle section of the image for the animation when the mouse
        #leaves the button
        startButtonOver = startButtonSprites.get_image(0,72,201,72)
        #Grabs the top section of the image for the animation when the mouse is
        #over the button
        startButtonDown = startButtonSprites.get_image(0,144,201,72)
        #Grabs the bottom section of the image for the mouse button held down
        #animation
        def startNow():
            print("Start Button")
        self.startButton = Button(startNow,startButtonUp, \
                                  startButtonDown,startButtonOver)
        #assignes the button variables to one single variable which is used
        #in the drawscreen function set below
        
        ########## OPTION BUTTON CODE ##########
        
        optionButtonSprites = SpriteSheet("button-start-spritesheet.png")
        optionButtonUp = optionButtonSprites.get_image(0,0,201,72)
        #Grabs the middle section of the image for the animation when the mouse
        #leaves the button
        optionButtonOver = optionButtonSprites.get_image(0,72,201,72)
        #Grabs the top section of the image for the animation when the mouse is
        #over the button
        optionButtonDown = optionButtonSprites.get_image(0,144,201,72)
        #Grabs the bottom section of the image for the mouse button held down
        #animation
        def optionNow():
            print("Option Button")
        self.optionButton = Button(optionNow,optionButtonUp, \
                                   optionButtonDown,optionButtonOver)
        self.optionButton.x = 100
        self.optionButton.y = 400
        
        ########## QUIT BUTTON CODE ##########
        
        quitButtonSprites = SpriteSheet("button-start-spritesheet.png")
        quitButtonUp = quitButtonSprites.get_image(0,0,201,72)
        #Grabs the middle section of the image for the animation when the mouse
        #leaves the button
        quitButtonOver = quitButtonSprites.get_image(0,72,201,72)
        #Grabs the top section of the image for the animation when the mouse is
        #over the button
        quitButtonDown = quitButtonSprites.get_image(0,144,201,72)
        #Grabs the bottom section of the image for the mouse button held down
        #animation
        def quitNow():
            print("Quit Button")
            sys.exit()
        self.quitButton = Button(quitNow,quitButtonUp, \
                                 quitButtonDown,quitButtonOver)
        self.quitButton.x = 400
        self.quitButton.y = 100
    
        
    ########## GAME LOOP ##########
        while playing:
            delta = self.clock.tick(FRAMERATE)
            #Forces the actions in a game to always move the same speed
            #and reach the same outcome regardless of how fast one's computer
            #is
            for event in pygame.event.get():
                if event.type==QUIT:
                    self.quit()
            
            self.processLogic(delta)
            self.drawScreen()
            pygame.display.flip()
    def quit(self):
        pygame.quit()
        sys.exit()
               
    def processLogic(self,delta):
        self.startButton.update(delta)
        self.quitButton.update(delta)
        self.optionButton.update(delta)
    
    def drawScreen(self):
        self.surface.fill(BGCOLOR)
        #Constantly fills the screen with white every frame
        centerOfScreen = self.getCenterOfScreen()
        centerOfPlayer = self.player.getCenter()
        self.player.x = centerOfScreen[0]-centerOfPlayer[0]
        self.player.y = centerOfScreen[1]-centerOfPlayer[1]
        self.player.draw(self.surface)
        self.startButton.draw(self.surface)
        #draws start button
        self.quitButton.draw(self.surface)
        #draws quit button
        self.optionButton.draw(self.surface)
        #draws option button
                
    def getCenterOfScreen(self):
        return(WINDOWWIDTH/2,WINDOWHEIGHT/2)
    
if __name__=='__main__':
    game = Game()
    game.main()
                
class Levels:
    #level menu
    #level 0 that acts like a type of overworld to allow the player
    #to choose their own level and this will replace a typical menu
    ########## VARIABLES ##########
    #obstacles
    #hazards
    #enemies
    #UI
    #buttons would be in the UI
    #backGround
    #update levels then the player
    #level.update(delta)
    #player.update(delta,levels)
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    
    ########## MAIN FUNCTION ##########
    drawFunction
    updateFunction(delta)
    
    
class Animation:
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class Platform:
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class Interface:
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class Menu:
    #has start, option, and quit button
    #animated backgrounds
    
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class NPC(Animation):
    ########## VARIABLES ##########
    dead = False
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class Collectables(Animation):
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class Hazards(Animation):
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    
class Destructables(Animation):
    ########## VARIABLES ##########
    
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
