'''
Created on Nov 7, 2017

@author: student
'''
import pygame
import sys, os, math
from pygame import *
from random import randint

WINDOWWIDTH = 1024
WINDOWHEIGHT = 768
GAMENAME = "Underground Battle NY"
FRAMERATE = 60
BGCOLOR = (255,255,255)

class Game:
    ########## VARIABLES ##########
    score = 0
    levels = []
    ########## CONSTRUCTOR ##########
    def __init__(self):
        pass
    ########## MAIN FUNCTION ##########
    def main(self):
        playing = True
        pygame.init()
        clock = pygame.time.Clock()
        self.surface = pygame.display.set_mode((WINDOWWIDTH,WINDOWHEIGHT))
        pygame.display.set_caption(GAMENAME)
        
        ########## GAME LOOP ##########
        while playing:
            delta = clock.tick(FRAMERATE)
            #Forces the actions in a game to always move the same speed
            #and reach the same outcome regardless of how fast one's computer
            #is
            for event in pygame.event.get():
                if event.type==QUIT:
                    self.quit()
            self.processLogic(delta)
            self.drawScreen()
            pygame.display.flip()
    def quit(self):
        pygame.quit()
        sys.exit()
               
    def processLogic(self,delta):
        pass
    
    def drawScreen(self):
        self.surface.fill(BGCOLOR)
    
if __name__=='__main__':
    game = Game()
    game.main()